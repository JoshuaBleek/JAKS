#!/bin/bash
scp ko58@10.244.11.197:/home/ko58/git/JAKS/package.sh /home/ko58/git/JAKS/scripts
